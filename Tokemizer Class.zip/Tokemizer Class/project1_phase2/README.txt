name:Xander Maniaci

my code:the code for this project was written by me using the template provided by Ali Kooshesh. some of the functions for printing the map also used pieces of example code given on canvas. 
no code used in my solution came from another student.

others code:I have provided one small line of code to a classmate and I have discussed possible solutions to phase two of this project with some classmates. 
for starters I have talked ian, Teo, mark and america about possible implementations of the map as well as the open tag stack. I have seen some of there code at a glance when they where working in the lab 
but I have not used any of it as i was ahead of all of them at that point when implementing phase 2. I did provide one line of code to america on tuesday during corins office hours which was #endif
//PROJECT1_PHASE2_STUDENT_FILES_OPENTAGSTACK_HPP because she was having trouble getting her stack implementation to run without syntax errors. any refference to the stack vector would cause a error
in her version of that class. ultimately I dont think that was the issue as corin helped her fix that issue. beside that instance I have not provided any other code to any other class mate. other students 
may ask me for help since I am finished a day early but I will do my best to not give them the answer and will not provide any code for them. I will only giving them helpful hints and a push in the right 
direction if there stuck.

implementation:this code runs as intented with all features presented in the output of sampleInput2_output.txt