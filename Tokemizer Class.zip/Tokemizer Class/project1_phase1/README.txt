name:Xander Maniaci

code:the code for this project was written by me using the template provided by Ali Kooshesh.

I have not provided my code to anyone in class however I have discussed possible solutions to phase one of this project with some classmates. 
in perticular ian and I had a few discussions about what constitutes a special character and some good ways of keeping track of the charPosition.
implementation: as far as I tested phase one of this project should be properly implemented. the line number char count and output should all be correct. 
I tested my solution on all three test txt files which all came out correctly.